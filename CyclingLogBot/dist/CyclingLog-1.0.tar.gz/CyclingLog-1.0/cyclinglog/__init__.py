#!/usr/bin/env python
#-*- coding:utf-8 -*-

from cyclinglog.entry_points import main
